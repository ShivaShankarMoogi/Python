Length = int(input("Enter a Length: "))
breadth = int(input("Enter a Breadth: "))

Area = Length*breadth
Perimeter = 2*(Length+breadth)
print("Area of the Rectangle :",Area)
print("Perimeter of the Rectangle :",Perimeter)
